![Image alt](https://github.com/KatsiarynaDzibrova/lab1_pinguins/blob/master/image.png)

Графическое приложение с использованием WinAPI и палок, реализация паттерна MVC.
